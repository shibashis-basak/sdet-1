package suiteCRMStepDefinitions;


import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class activity4 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page4 and log in with valid credential4$")
    public void loginPage() throws InterruptedException {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
    
        driver.manage().window().maximize();
        //Enter username
        driver.findElement(By.id("user_name")).sendKeys("admin");
        //Enter password
        driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
        //Click Login
        driver.findElement(By.id("bigbutton")).click();
        Thread.sleep(4000);
    }
    
    @When("^Navigate to All to Products to Create Product$")
    public void createProduct()
    {
    	Actions act= new Actions(driver);
    	
    	WebElement all = driver.findElement(By.id("grouptab_5"));
    	act.moveToElement(all).click().build().perform();
    	
    	  	
    	JavascriptExecutor js = (JavascriptExecutor)driver;
    	js.executeScript("arguments[0].scrollIntoView(true);", driver.findElement(By.xpath(".//ul[@class='dropdown-menu']/li/a[text()='Products']")));
    	
    	WebElement products = driver.findElement(By.xpath(".//ul[@class='dropdown-menu']/li/a[text()='Products']"));
    	act.moveToElement(products).click().build().perform();
    	
    	
    	WebElement createProduct = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Create Product")));
    	createProduct.click();
    	
    }
    @And("^Fill the \"(.*)\"$")
    public void fillDetails(String productName)
    {
    		wait.until(ExpectedConditions.elementToBeClickable(By.id("name")));
    		driver.findElement(By.id("name")).sendKeys(productName);
    }
    
	@And("^Click on Save product$")
	public void clickOnSaveProduct()
	{
		driver.findElement(By.id("SAVE")).click();
	}
	@Then("^Navigate to the View products page to all results$")
    public void checkResult()
    {
		driver.findElement(By.linkText("View Products")).click();
    }
    
    @And("^Close the browser4$")
    public void closeBrowser() 
    {
        //Close browser
        driver.close();
    }

}