package alchemyJobsStepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class activity1 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/jobs/wp-admin");
    }
    
    @And("^log in with valid credentials$")
    public void enterCredentials() {
        //Enter username
        driver.findElement(By.id("user_login")).sendKeys("root");
        //Enter password
        driver.findElement(By.id("user_pass")).sendKeys("pa$$w0rd");
        //Click Login
        driver.findElement(By.id("wp-submit")).click();
    }
    
    @When("^Locate the left hand menu and click the menu item that says Users$")
    public void clickOnUsers()
    {
    	WebElement users = driver.findElement(By.xpath(".//div[@class='wp-menu-name' and text()='Users']"));
    	Actions act = new Actions(driver);
    	act.moveToElement(users).build().perform();
    	
    }
    
    @And("^Locate the Add New button and click it$")
    public void clickOnAddNew()
    {
    	WebElement addNew = wait.until(ExpectedConditions.visibilityOfElementLocated(By.linkText("Add New")));
    	addNew.click();
    }
    
    @And("^Fill in the necessary details$")
    public void fillDetails() 
    {
    	driver.findElement(By.id("user_login")).sendKeys("IBMCucumberTestProject1");
    	driver.findElement(By.id("email")).sendKeys("cucumber.test1@gmail.com");
    	driver.findElement(By.xpath(".//button[text()='Show password']")).click();
    	//driver.findElement(By.xpath(".//input[@id='pass1']")).clear();
    	//driver.findElement(By.xpath(".//input[@id='pass1']")).sendKeys("Abcd@1234");
    	
    }

    @And("^Click the Add New User button$")
    public void clickOnAddNewUser()
    {
    	driver.findElement(By.id("createusersub")).click();
    }
    
    @Then("^Verify that the user was created$")
    public void verification()
    {
    	WebElement confirmation = driver.findElement(By.xpath(".//div[@id='message']/p"));
    	String confirmationMsg = confirmation.getText();
    	Assert.assertEquals(confirmationMsg, "New user created. Edit user");
    	
    }
    
    @And("^Close the browser$")
    public void closeBrowser() {
        //Close browser
        driver.close();
    }

}