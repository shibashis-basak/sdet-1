package orangeHRMStepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class activity4 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page4$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
    }
    
    @And("^log in with valid credentials4$")
    public void enterCredentials() {
        //Enter username
        driver.findElement(By.id("txtUsername")).sendKeys("orange");
        //Enter password
        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
        //Click Login
        driver.findElement(By.id("btnLogin")).click();
    }
    
    
    @When("^Navigate to the Recruitment page4$")
    public void navigateToRecriutment() 
    {
    	driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
    }
	@And("^Click on the Vacancies menu item to navigate to the vacancies page4$")
	public void navigateToVacancies() 
    {
    	driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
    }
	@And("^Click on the Add button to navigate to the Add Job Vacancy form4$")
	public void clickToAddVacancy() 
    {
    	driver.findElement(By.id("btnAdd")).click();
    }
	@And("^Fill out the necessary details \"(.*)\" and \"(.*)\" and \"(.*)\"$")
	public void enterDetails(String addJobTitle,String addVacancyName,String addManager) 
    {
    	WebElement jobTitle = driver.findElement(By.id("addJobVacancy_jobTitle"));
    	Select title = new Select(jobTitle);
    	title.selectByVisibleText(addJobTitle);
    	
    	driver.findElement(By.id("addJobVacancy_name")).sendKeys(addVacancyName);
    	
    	
    	
    	WebElement hiringMngr = driver.findElement(By.id("addJobVacancy_hiringManager"));
    	hiringMngr.sendKeys(addManager);
    }
	@And("^Click the Save button to save the vacancy4$")
	public void clickOnSave() 
    {
    	driver.findElement(By.id("btnSave")).click();
    }
	@Then("^Verify the vacancy with \"(.*)\" and \"(.*)\"$")
	public void verification(String searchTitle, String searchManager) 
    {
		driver.findElement(By.id("btnBack")).click();
    	
    	WebElement searchJobTitle = driver.findElement(By.id("vacancySearch_jobTitle"));
    	Select jobTitle = new Select(searchJobTitle);
    	jobTitle.selectByVisibleText(searchTitle);
    	
    	WebElement searchHiringMngr = driver.findElement(By.id("vacancySearch_hiringManager"));
    	Select searchMngr = new Select(searchHiringMngr);
    	searchMngr.selectByVisibleText(searchManager);
    	
    	driver.findElement(By.id("btnSrch")).click();
    	
    	List<WebElement> results= driver.findElements(By.xpath(".//table[@id='resultTable']/tbody/tr"));
    	if (results.size()>0)
    	{
    		System.out.println("We have matching results");
    	}
    	else
    	{
    		System.out.println("Job is not added");
    	}
    }
    
    
    @And("^Close the browser4$")
    public void closeBrowser() {
        //Close browser
        driver.close();
    }

}