package orangeHRMStepDefinitions;


import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class activity3 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page3$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
    }
    
    @And("^log in with valid credentials3$")
    public void enterCredentials() {
        //Enter username
        driver.findElement(By.id("txtUsername")).sendKeys("orange");
        //Enter password
        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
        //Click Login
        driver.findElement(By.id("btnLogin")).click();
    }
    
    @When("^Click on PIM option$")
    public void clickOnPIM() 
    {
    	driver.findElement(By.id("menu_pim_viewPimModule")).click();
    }
	@And("^Click the Add button to add a new Employee$")
	public void clickOnAdd() 
    {
    	driver.findElement(By.id("menu_pim_addEmployee")).click();
    }
	@And("^Create Login Details checkbox is checked$")
	public void checkCreateLoginDetailsCheckbox() 
    {
    	
		WebElement loginDetailsCheck =  driver.findElement(By.id("chkLogin"));
		if(loginDetailsCheck.isSelected()== false)
			loginDetailsCheck.click();
    }
	@And("^Fill \"(.*)\" and \"(.*)\" and \"(.*)\" and \"(.*)\"$")
	public void enterDetails(String firstName, String lastName, String userName,String status) 
    {
    	driver.findElement(By.id("firstName")).sendKeys(firstName);
    	driver.findElement(By.id("lastName")).sendKeys(lastName);
    	driver.findElement(By.id("user_name")).sendKeys(userName);
    	WebElement sts = driver.findElement(By.id("status"));
    	Select slct = new Select(sts);
    	slct.selectByVisibleText(status);
    }
	@And("^Click the Save button to add employee$")
	public void clickOnSave() 
    {
    	driver.findElement(By.id("btnSave")).click();
    }
	@Then("^Verify that the employees have been created$")
	public void verification() 
    {
    	String fullName = driver.findElement(By.xpath(".//div[@id='employee-details']/div[@id='sidebar']/div[@id='profile-pic']/h1")).getText();
    	System.out.println(fullName);
    	System.out.println("The employee is created");
    	
    }
    
    @And("^Close the browser3$")
    public void closeBrowser() {
        //Close browser
        driver.close();
    }

}