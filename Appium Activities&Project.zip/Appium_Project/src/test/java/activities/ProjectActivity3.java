package activities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class ProjectActivity3 {
  
  AppiumDriver<MobileElement> driver = null;

  @BeforeClass
  public void beforeClass() throws MalformedURLException {
      // Set the Desired Capabilities
      DesiredCapabilities caps = new DesiredCapabilities();
      caps.setCapability("deviceName", "Pixel 4 Pie");
      caps.setCapability("platformName", "Android");
      caps.setCapability("automationName", "UiAutomator2");
      caps.setCapability("appPackage", "com.google.android.keep");
      caps.setCapability("appActivity", "activities.BrowseActivity");
      caps.setCapability("noReset", true);

      // Instantiate Appium Driver
      URL appServer = new URL("http://0.0.0.0:4723/wd/hub");
      driver = new AndroidDriver<MobileElement>(appServer, caps);
  }

  @Test
  public void addtask() {
	  
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  
	 //Add note
	  driver.findElementByAccessibilityId("New text note").click();
	  driver.findElementById("editable_title").sendKeys("Test Note");
	  driver.findElementById("edit_note_text").sendKeys("Appium Project Activity 3");
	  driver.findElementById("menu_switch_to_list_view").click();
	  driver.findElementByXPath("//android.widget.LinearLayout[@content-desc=\"Time - Currently selected - 4:00 PM\"]/android.widget.Spinner/android.widget.TextView").click();
	  driver.findElementByXPath("/hierarchy/android.widget.FrameLayout/android.widget.FrameLayout/android.widget.ListView/android.widget.LinearLayout[2]/android.widget.TextView[1]").click();
	  driver.findElementById("save").click();
	  driver.findElementByXPath("//android.widget.ImageButton[@content-desc=\"Navigate up\"]").click();
	  String str1= driver.findElementById("index_note_title").getText();
	  Assert.assertEquals(str1, "Test Note");
	  
	  
	  	  	  
	
  }
  
  
  @AfterClass
  public void afterClass() {
      driver.quit();
  }
}
