package suiteCRMStepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class activity1 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
    }
    
    @When("^log in with valid credentials$")
    public void enterCredentials() throws InterruptedException {
        //Enter username
        driver.findElement(By.id("user_name")).sendKeys("admin");
        //Enter password
        driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
        //Click Login
        driver.findElement(By.id("bigbutton")).click();
        Thread.sleep(4000);
    }
    
    @Then("^Count the number of Dashlets on the homepage$")
    public void countDashlet()
    {
    	List<WebElement> dashlet = driver.findElements(By.className("dashlet-title"));
    	
    	System.out.println(dashlet.size());
    	
    }
    
    @And("^Print title of each dashlet$")
    public void titleOfDashlet()
    {
    	List<WebElement> dashletNames = driver.findElements(By.xpath("//td[@class='dashlet-title']/h3/span[2]"));
    	for(WebElement name: dashletNames)
    	{
    		System.out.println(name.getText());
    	}
    	
    }
    
    
    @And("^Close the browser$")
    public void closeBrowser() {
        //Close browser
        driver.close();
    }

}