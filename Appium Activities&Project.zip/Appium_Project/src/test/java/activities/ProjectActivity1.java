package activities;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.android.AndroidDriver;

public class ProjectActivity1 {
  
  AppiumDriver<MobileElement> driver = null;

  @BeforeClass
  public void beforeClass() throws MalformedURLException {
      // Set the Desired Capabilities
      DesiredCapabilities caps = new DesiredCapabilities();
      caps.setCapability("deviceName", "Pixel 4 Pie");
      caps.setCapability("platformName", "Android");
      caps.setCapability("automationName", "UiAutomator2");
      caps.setCapability("appPackage", "com.google.android.apps.tasks");
      caps.setCapability("appActivity", ".ui.TaskListsActivity");
      caps.setCapability("noReset", true);

      // Instantiate Appium Driver
      URL appServer = new URL("http://0.0.0.0:4723/wd/hub");
      driver = new AndroidDriver<MobileElement>(appServer, caps);
  }

  @Test
  public void addtask() {
	  
	  driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	  
	 //1st task
	  driver.findElementById("tasks_fab").click();
	  driver.findElementById("add_task_title").sendKeys("Complete Activity with Google Tasks");
	  driver.findElementById("add_task_done").click();
	  String str1=driver.findElementByXPath("//android.widget.FrameLayout[@content-desc=\"Complete Activity with Google Tasks\"]/android.widget.LinearLayout/android.widget.TextView").getText();
	  Assert.assertEquals(str1, "Complete Activity with Google Tasks");
	  
	  
	//2nd task
	  driver.findElementById("tasks_fab").click();
	  driver.findElementById("add_task_title").sendKeys("Complete Activity with Google Keep");
	  driver.findElementById("add_task_done").click();
	  String str2=driver.findElementByXPath("//android.widget.FrameLayout[@content-desc=\"Complete Activity with Google Keep\"]/android.widget.LinearLayout/android.widget.TextView").getText();
	  Assert.assertEquals(str2, "Complete Activity with Google Keep");
    
	//3rd task
	  driver.findElementById("tasks_fab").click();
	  driver.findElementById("add_task_title").sendKeys("Complete the second Activity with Google Keep");
	  driver.findElementById("add_task_done").click();
	  String str3=driver.findElementByXPath("//android.widget.FrameLayout[@content-desc=\"Complete the second Activity with Google Keep\"]/android.widget.LinearLayout/android.widget.TextView").getText();
	  Assert.assertEquals(str3, "Complete the second Activity with Google Keep");
	  
  }
  
  
  @AfterClass
  public void afterClass() {
      driver.quit();
  }
}
