package orangeHRMStepDefinitions;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class activity2 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page2$")
    public void loginPage() {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("http://alchemy.hguy.co:8080/orangehrm/symfony/web/index.php/auth/login");
    }
    
    @And("^log in with valid credentials2$")
    public void enterCredentials() {
        //Enter username
        driver.findElement(By.id("txtUsername")).sendKeys("orange");
        //Enter password
        driver.findElement(By.id("txtPassword")).sendKeys("orangepassword123");
        //Click Login
        driver.findElement(By.id("btnLogin")).click();
    }
    
    
    @When("^Navigate to the Recruitment page2$")
    public void navigateToRecriutment() 
    {
    	driver.findElement(By.id("menu_recruitment_viewRecruitmentModule")).click();
    }
    
	@And("^click on the Add button to add candidate information$")
	public void navigateToVacancies() 
    {
		driver.findElement(By.id("menu_recruitment_viewCandidates")).click();
    	driver.findElement(By.id("btnAdd")).click();
    }
	
	
	@And("^fill in the details of the candidate$")
	public void enterDetails() 
    {
    	driver.findElement(By.id("addCandidate_firstName")).sendKeys("TestFirstName");
    	driver.findElement(By.id("addCandidate_lastName")).sendKeys("TestLastName");
    	driver.findElement(By.id("addCandidate_email")).sendKeys("test@gmail.com");
    }
	
	
	@And ("^Upload a resume to the form$")
	public void uploadResume()
	{
		
	}
	@And("^Click the Save button$")
	public void clickOnSave() 
    {
    	driver.findElement(By.id("btnSave")).click();
    }
	@Then("^Navigate back to the Recruitments page to confirm candidate entry$")
	public void verification() 
    {
    	driver.findElement(By.id("btnBack")).click();
    	driver.findElement(By.id("candidateSearch_candidateName")).sendKeys("TestFirstName TestLastName");
    	driver.findElement(By.id("btnSrch")).click();
    	
    	List<WebElement> results = driver.findElements(By.xpath(".//table[@id='resultTable']/tbody/tr"));
    	if(results.size()>0)
    		System.out.println("The Candidate is added");
    	else
    		System.out.println("The candidate is not added");
    	
    }
    
    
    @And("^Close the browser2$")
    public void closeBrowser() {
        //Close browser
        driver.close();
    }

}