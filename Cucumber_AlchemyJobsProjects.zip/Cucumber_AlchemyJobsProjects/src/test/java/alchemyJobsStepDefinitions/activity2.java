package alchemyJobsStepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class activity2 {

	 WebDriver driver;
	 WebDriverWait wait;
	
	@Given("^Open browser with Alchemy Jobs site and navigate to Jobs page$")
	public void openBrowser()
	{
		driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/jobs/");
        driver.findElement(By.xpath(".//a[text()='Jobs']")).click();
	}
	@When("^Find the Keywords search input field and type in keywords to search for jobs$")
	public void searchKeyword()
	{
		driver.findElement(By.id("search_keywords")).sendKeys("Automation Test Specialist");
	}
	@And("^Find the filter using XPath and filter job type to show only Full Time jobs$")
	public void filterFullTimeJobs()
	{
		WebElement freelance = driver.findElement(By.id("job_type_freelance"));
		if(freelance.isSelected()==true)
			freelance.click();
		
		WebElement fullTime = driver.findElement(By.id("job_type_full-time"));
		if(fullTime.isSelected()==false)
			fullTime.click();
		
		WebElement internship = driver.findElement(By.id("job_type_internship"));
		if(internship.isSelected()==true)
			internship.click();
		
		WebElement partTime = driver.findElement(By.id("job_type_part-time"));
		if(partTime.isSelected()==true)
			partTime.click();
		
		WebElement temporary = driver.findElement(By.id("job_type_temporary"));
		if(temporary.isSelected()==true)
			temporary.click();
		
		driver.findElement(By.className("search_submit")).click();
		
	}
	@And("^Find a job listing using XPath and it to see job details$")
	public void seeJobDeatils() throws InterruptedException
	{
		Thread.sleep(2000);
		driver.findElement(By.xpath(".//ul[@class='job_listings']/li[1]/a/div/h3[text()='Automation Test Specialist']")).click();	
	}
	@Then("^Find the title of the job listing using XPath and print it to the console$")
	public void printJobTitle()
	{
		System.out.println(driver.findElement(By.className("entry-title")).getText());
	}
	@And("^Find and Click on the Apply for job button$")
	public void clickOnApply()
	{
		driver.findElement(By.xpath(".//input[@value='Apply for job']")).click();
		
	}
	@And("^Close the browser1$")
	public void closeBrowser1()
	{
		driver.close();
	}
}
