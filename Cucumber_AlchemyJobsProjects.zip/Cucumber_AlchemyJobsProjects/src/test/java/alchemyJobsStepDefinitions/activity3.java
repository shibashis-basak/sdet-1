package alchemyJobsStepDefinitions;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class activity3 {
	
	WebDriver driver;
	WebDriverWait wait;
	
	@Given("^Open browser with Alchemy Jobs site$")
	public void openBrowser()
	{
		driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/jobs/");
        
	}
	@When("^Go to Post a Job page$")
	public void clickOnPostJob()
	{
		driver.findElement(By.id("menu-item-26")).click();
	}
	@And("^Enter \"(.*)\" and \"(.*)\" and \"(.*)\" and \"(.*)\"$")
	public void inputs(String myEmail, String jobTitle, String email, String companyName)
	{
		driver.findElement(By.id("create_account_email")).sendKeys(myEmail);
		driver.findElement(By.id("job_title")).sendKeys(jobTitle);
		driver.switchTo().frame("job_description_ifr");
		driver.findElement(By.id("tinymce")).sendKeys("Test Description");
		driver.switchTo().defaultContent();
		driver.findElement(By.id("application")).sendKeys(email);
		driver.findElement(By.id("company_name")).sendKeys(companyName);
	}
	@And("^Click submit$")
	public void submit()
	{
		driver.findElement(By.name("submit_job")).click();
		driver.findElement(By.id("job_preview_submit_button")).click();
	}
	@Then("^Go to the Jobs page$")
	public void goToJobs()
	{
		driver.findElement(By.id("menu-item-24")).click();
	}
	@And("^Confirm job listing is shown on page$")
	public void confirmJob()
	{
		driver.findElement(By.id("search_keywords")).sendKeys("TestTitle");
		driver.findElement(By.className("search_submit")).click();
		String jobTitleConfirm = driver.findElement(By.xpath(".//ul[@class='job_listings']/li[1]/a/div/h3")).getText();
		System.out.println(jobTitleConfirm);
	}
	

}
