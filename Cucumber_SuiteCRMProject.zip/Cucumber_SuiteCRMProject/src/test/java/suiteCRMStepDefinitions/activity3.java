package suiteCRMStepDefinitions;


import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class activity3 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page3 and log in with valid credential3$")
    public void loginPage() throws InterruptedException {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
    
        driver.manage().window().maximize();
        //Enter username
        driver.findElement(By.id("user_name")).sendKeys("admin");
        //Enter password
        driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
        //Click Login
        driver.findElement(By.id("bigbutton")).click();
        Thread.sleep(4000);
    }
    
    @When("^Navigate to Activities to Meetings to Schedule a Meeting$")
    public void navigateToscheduleMeeting()
    {
    	Actions act= new Actions(driver);
    	
    	WebElement activities = driver.findElement(By.id("grouptab_3"));
    	WebElement meeting = driver.findElement(By.id("moduleTab_9_Meetings"));
    	//act.moveToElement(activities).click().build().perform();
    	//act.moveToElement(meeting).click().build().perform();
    	act.moveToElement(activities).moveToElement(meeting).click().build().perform();
    	
    	WebElement scheduleMeeting = wait.until(ExpectedConditions.elementToBeClickable(By.linkText("Schedule Meeting")));
    	scheduleMeeting.click();
    	
    }
    @And("^Fill the details of the meeting$")
    public void fillDetails()
    {
    	wait.until(ExpectedConditions.elementToBeClickable(By.id("name"))).sendKeys("Test Meeting");
    	//driver.findElement(By.id("name")).sendKeys("Test Meeting");	
    }
    @And("^Search with \"(.*)\" and \"(.*)\" and add member to the meeting$")
    public void searchAndAddMembers(String firstName, String lastName)
    {
    	driver.findElement(By.id("search_first_name")).sendKeys(firstName);
    	driver.findElement(By.id("search_last_name")).sendKeys(lastName);
    	driver.findElement(By.id("invitees_search")).click();
    	    	
    	wait.until(ExpectedConditions.elementToBeClickable(By.id("invitees_add_1"))).click();
    }
	@And("^Click on Save meeting$")
	public void clickOnSave()
	{
		driver.findElement(By.id("SAVE_HEADER")).click();
	}
	@Then("^Navigate to the View meetings page to see results$")
    public void checkResult()
    {
		driver.findElement(By.linkText("View Meetings")).click();
		String checkMeeting = wait.until(ExpectedConditions.elementToBeClickable(By.xpath("//table[@class='list view table-responsive']/tbody/tr[1]/td[4]/b/a"))).getText();
		Assert.assertEquals("Test Meeting", checkMeeting);
    }
    
    @And("^Close the browser3$")
    public void closeBrowser() 
    {
        //Close browser
        driver.close();
    }

}