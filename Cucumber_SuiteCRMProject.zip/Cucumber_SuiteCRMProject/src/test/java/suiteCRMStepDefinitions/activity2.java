package suiteCRMStepDefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;


public class activity2 {
    WebDriver driver;
    WebDriverWait wait;
    
    @Given("^Open a browser and Navigate to log in page2 and log in with valid credential2$")
    public void loginPage() throws InterruptedException {
        //Setup instances
        driver = new FirefoxDriver();
        wait = new WebDriverWait(driver, 10);
        
        //Open browser
        driver.get("https://alchemy.hguy.co/crm/index.php?action=Login&module=Users");
    
    
        //Enter username
        driver.findElement(By.id("user_name")).sendKeys("admin");
        //Enter password
        driver.findElement(By.id("username_password")).sendKeys("pa$$w0rd");
        //Click Login
        driver.findElement(By.id("bigbutton")).click();
        Thread.sleep(4000);
    }
    
    @When("^Navigate to Sales to Leads to Create Lead$")
    public void navigateToCreateLead()
    {
    	driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
    	WebElement sales = driver.findElement(By.id("grouptab_0"));
    	
    	WebElement leads = driver.findElement(By.id("moduleTab_9_Leads"));
    	
    	Actions act = new Actions(driver);
    	act.moveToElement(sales).click().build().perform();
    	act.moveToElement(leads).click().build().perform();
    	
    	
    	driver.findElement(By.xpath(".//div[@class='actionmenulink' and text()='Create Lead']")).click();
    	
    	
    }
    @And("^Fill \"(.*)\" and \"(.*)\"$")
    public void fillDetails(String firstName, String lastName)
    {
    	
    	
    	wait.until(ExpectedConditions.elementToBeClickable(By.id("first_name"))).click();
    	driver.findElement(By.id("first_name")).sendKeys(firstName);
    	
    	WebElement salutation = driver.findElement(By.id("salutation"));
    	Select salute = new Select(salutation);
    	salute.selectByValue("Mr.");
    	
    	driver.findElement(By.id("last_name")).sendKeys(lastName);
    }
	@And("^Click on Save$")
	public void clickOnSave()
	{
		driver.findElement(By.id("SAVE")).click();
	}
	@Then("^Navigate to the View Leads page to see results$")
    public void checkResult()
    {
		driver.manage().timeouts().implicitlyWait(4, TimeUnit.SECONDS);
		driver.findElement(By.linkText("View Leads")).click();
    }
    
    @And("^Close the browser2$")
    public void closeBrowser() 
    {
        //Close browser
        driver.close();
    }

}